# Title of Dataset
Filtered daily records from the global eddy-covariance towers for assessing the impacts of high vapor pressure deficit and low soil moisture on ecosystem productivity

We used daily energy, water, and carbon fluxes and meteorological observations from the FLUXNET2015 Tier One (https://fluxnet.org/data/download-data/), AmeriFlux ONEFlux (https://ameriflux.lbl.gov/data/download-data/), and ICOS drought-2018 (https://www.icos-cp.eu/data-products/YVR0-4898) datasets.The FLUXNET2015 Tier one, the AmeriFlux, and the ICOS are all licensed under the Creative Commons Attribution 4.0 International license (CC-BY-4.0) (https://creativecommons.org/licenses/by/4.0/). The CC-BY-4.0 license specifies that the data user is free to share (copy and redistribute the material in any medium or format) and/or adapt (remix, transform, and build upon the material) for any purpose. We have provided a link to the licence and data source in the paper and this document. According to the specific request of FLUXNET2015 Tier one, we have cited the paper by Pastorello et al. (2020) in the paper and this documents. We also listed each site that we used by its FLUXNET ID in the paper and deposited to Dryad.  

Pastorello, G. et al. (2020). The FLUXNET2015 dataset and the ONEFlux processing pipeline for eddy covariance data. Scientific Data, 7(1): 225. DOI:10.1038/s41597-020-0534-3.  



## Description of the data and file structure
The data format is .csv or .xlsx

The variable information in the files of 'filtered_daily_records', 'filtered_daily_records_in normal and drought years', and 'filtered_daily_records_surface_layer_SM_vs_deeper_SM' is:
TIMESTAMP, YYYYMMDDHHMM, ISO timestamp-short format
TA, deg C, Air temperature
Rs, W m-2, Incoming shortwave radiation
VPD, kPa, Vapor pressure deficit
SWC_surface_layer, %, Surface layer soil water content
SWC_deeper, %, Depper soil water content
GPP, gC m-2 d-1, Gross primary production

The variable information in the files of 'variability_of_G1_across_sites'is:
Gs, mol m-2 s-1, daily ecosystem conductance
